package review.model;

public interface CompanyReviewDAO {

	
	
}
