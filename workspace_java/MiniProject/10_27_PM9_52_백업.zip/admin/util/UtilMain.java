package admin.util;

public class UtilMain {

	public static void main(String[] args) {
		
		Util.rock_scissors_paper();

	}// 

}
