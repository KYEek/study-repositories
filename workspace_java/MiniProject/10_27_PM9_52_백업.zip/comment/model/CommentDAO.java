package comment.model;

import java.util.List;
import java.util.Map;

import comment.domain.CommentDTO;

public interface CommentDAO {

	// 후기에 답변작성하기 (기업만 가능하다)
	int writeComment(Map<String, String> paraMap);

	// 단순 답변조회 
	List<CommentDTO> commentList(String review_no);

	
	// 답변이 있는지 조회
	boolean existComment(int fk_review_no);


}
