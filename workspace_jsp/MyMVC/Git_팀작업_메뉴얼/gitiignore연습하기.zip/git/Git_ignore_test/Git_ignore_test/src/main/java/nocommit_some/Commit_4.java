package nocommit_some;

public class Commit_4 {

	public static void main(String[] args) {
	
	/*
		Commit_4.java 파일은 ignore 대상이 아닌 파일이므로 Commit 대상이 됩니다. 
	*/
		System.out.println("## Commit_4.java 파일입니다. ##");		

	}

}
